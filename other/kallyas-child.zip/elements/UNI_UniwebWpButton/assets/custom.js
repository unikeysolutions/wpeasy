  var $=jQuery.noConflict();
function jsUcfirst(string) 
{
    return string.charAt(0).toUpperCase() + string.slice(1);
}
var h1catch = $('h1').html();
var replaced = $(".WpBtnCatch").html().replace('xH1TAGHEREx',jsUcfirst(h1catch));
$(".WpBtnCatch").html(replaced);
