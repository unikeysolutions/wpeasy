<?php
if ( ! defined( 'ABSPATH') ) {
    return;
}
/* Include */
include 'theme_register.php'; // Registed All Elements 
include 'inc/page.categories.php'; // Page set to Categories
include 'inc/inc.zionhook.php'; // 
/* Include  End */ 
add_action( 'wp_enqueue_scripts', 'kl_child_scripts',11 );
function kl_child_scripts() {

	/**
	 * Load the child theme's style.css *after* the parent theme's one.
	 */
	wp_deregister_style( 'kallyas-styles' );
    wp_enqueue_style( 'kallyas-styles', get_template_directory_uri().'/style.css', '' , ZN_FW_VERSION );
    wp_enqueue_style( 'kallyas-child', get_stylesheet_uri(), array('kallyas-styles') , ZN_FW_VERSION );
   
	/** 
	 * Load a custom JavaScript file.
	 * To use, please uncomment by removing the: "//"
	 */

	// wp_enqueue_script( 'zn_script_child', get_stylesheet_directory_uri() .'/js/zn_script_child.js' , '' , ZN_FW_VERSION , true );
}

/**
 * Load child theme's textdomain.
 */
add_action( 'after_setup_theme', 'kallyasChildLoadTextDomain' );
function kallyasChildLoadTextDomain(){
   load_child_theme_textdomain( 'zn_framework', get_stylesheet_directory().'/languages' );
}
 

/**
 * Override Logo’s heading wrapper (H1)
 */
function wp2356_change_logo_tag() {
  return 'div';
}
add_filter( 'zn_logo_tag', 'wp2356_change_logo_tag', 50 );

/**
 * Override Subheader’s heading tag to H1
 */
function mysite_change_subheader_title_tag() {
   return 'h1';
}
add_filter('zn_subheader_title_tag', 'mysite_change_subheader_title_tag');

/**
 * Override Subheader’s heading tag to H2
 */
function mysite_change_subheader_subtitle_tag() {
   return 'h2';
}
add_filter('zn_subheader_subtitle_tag', 'mysite_change_subheader_subtitle_tag');

 