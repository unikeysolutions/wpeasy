 <?php
 
/**
 * Uniweb Element Loader 
 *
 * @package  Kallyas
 * @category Page Builder
 * @author   Team Uniweb
 * @since    4.0.0
 */


/* Uniweb Whatsapp Button id=300 */
add_action( 'znb:elements:register_elements', 'Load_WPButton' );
function Load_WPButton( $zionBuilder ) {

  
     include get_stylesheet_directory() . '/elements/UNI_UniwebWpButton/button.php';



    $zionBuilder->registerElement( new UNI_Button( array(
        'id' => '300',
        'name' => __( 'Uniweb WP Button', 'zion-builder' ),
        'level' => 2,
        'category' => 'Uniweb',
        'keywords' => array( 'scroll' ),
    ) ) );

}
/* Uniweb Action Box id=301 */
add_action( 'znb:elements:register_elements', 'Load_ActionBox' );
function Load_ActionBox( $zionBuilder ) {

  
     include get_stylesheet_directory() . '/elements/UNI_UniwebActionBox/UNI_ActionBox.php';



    $zionBuilder->registerElement( new UNI_ActionBox( array(
        'id' => '301',
        'name' => __( 'Uniweb ActionBox', 'zion-builder' ),
        'level' => 2,
        'category' => 'Uniweb',
        'keywords' => array( 'scroll' ),
    ) ) );

}
/* Uniweb Bcc Contact Form id=302 */
add_action( 'znb:elements:register_elements', 'Load_BccContact' );
function Load_BccContact( $zionBuilder ) {

  
     include get_stylesheet_directory() . '/elements/UNI_BccContact/UNI_contact_form.php';



    $zionBuilder->registerElement( new UNI_BccContactForm( array(
        'id' => '302',
        'name' => __( 'Uniweb Bcc Contact Form', 'zion-builder' ),
        'level' => 2,
        'category' => 'Uniweb',
        'keywords' => array( 'scroll' ),
    ) ) );

}
/* Uniweb List id=303 */
add_action( 'znb:elements:register_elements', 'Load_List' );
function Load_List( $zionBuilder ) {

  
     include get_stylesheet_directory() . '/elements/UNI_List/uni_list.php';



    $zionBuilder->registerElement( new Uni_List( array(
        'id' => '303',
        'name' => __( 'Uniweb List', 'zion-builder' ),
        'level' => 2,
        'category' => 'Uniweb',
        'keywords' => array( 'scroll' ),
    ) ) );

}
/* Uniweb Icon Box id=304 */
add_action( 'znb:elements:register_elements', 'Load_IconBox' );
function Load_IconBox( $zionBuilder ) {

    include get_stylesheet_directory() . '/elements/UNI_IconBox/UNI_IconBox.php';



    $zionBuilder->registerElement( new UNI_IconBox( array(
        'id' => '304',
        'name' => __( 'Uniweb Icon Box', 'zion-builder' ),
        'level' => 3,
        'category' => 'Uniweb',
        'keywords' => array( 'scroll' ),
    ) ) );
 
}

/* 
latestPage Elements | Total 5 part

305-309

*/
// Latest Page 1
add_action( 'znb:elements:register_elements', 'Load_LatestPage' );
function Load_LatestPage( $zionBuilder ) {

    include get_stylesheet_directory() . '/elements/UNI_LatestPage/LatestPage.php';



    $zionBuilder->registerElement( new UNI_LatestPage( array(
        'id' => '305',
        'name' => __( 'Uniweb Latest Page', 'zion-builder' ),
        'level' => 3,
        'category' => 'Uniweb',
        'keywords' => array( 'scroll' ),
    ) ) );
 
}
// Latest Page 2
add_action( 'znb:elements:register_elements', 'Load_LatestPage2' );
function Load_LatestPage2( $zionBuilder ) {

    include get_stylesheet_directory() . '/elements/UNI_LatestPage2/LatestPage2.php';



    $zionBuilder->registerElement( new UNI_LatestPage2( array(
        'id' => '306',
        'name' => __( 'Uniweb Latest Page 2', 'zion-builder' ),
        'level' => 3,
        'category' => 'Uniweb',
        'keywords' => array( 'scroll' ),
    ) ) );
 
}
// Latest Page 3
add_action( 'znb:elements:register_elements', 'Load_LatestPosts3' );
function Load_LatestPosts3( $zionBuilder ) {

    include get_stylesheet_directory() . '/elements/UNI_LatestPage3/LatestPage3.php';



    $zionBuilder->registerElement( new UNI_LatestPage3( array(
        'id' => '307',
        'name' => __( 'Uniweb Latest Page 3', 'zion-builder' ),
        'level' => 3,
        'category' => 'Uniweb',
        'keywords' => array( 'scroll' ),
    ) ) );
 
}
// Latest Page 4

add_action( 'znb:elements:register_elements', 'Load_LatestPosts4' );
function Load_LatestPosts4( $zionBuilder ) {

    include get_stylesheet_directory() . '/elements/UNI_LatestPage4/LatestPage4.php';



    $zionBuilder->registerElement( new UNI_LatestPage4( array(
        'id' => '308',
        'name' => __( 'Uniweb Latest Page 4', 'zion-builder' ),
        'level' => 3,
        'category' => 'Uniweb',
        'keywords' => array( 'scroll' ),
    ) ) );
 
}
// Latest Page 5

add_action( 'znb:elements:register_elements', 'Load_LatestPosts5' );
function Load_LatestPosts5( $zionBuilder ) {

    include get_stylesheet_directory() . '/elements/UNI_LatestPage5/LatestPage5.php';



    $zionBuilder->registerElement( new UNI_LatestPage5( array(
        'id' => '309',
        'name' => __( 'Uniweb Latest Page 5', 'zion-builder' ),
        'level' => 3,
        'category' => 'Uniweb',
        'keywords' => array( 'scroll' ),
    ) ) );
 
} 
/* 
LatestPosts Elements End
*/ 